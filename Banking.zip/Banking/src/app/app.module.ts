import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppComponent } from './app.component';
import { HomeComponent } from './home/home.component';
import { LoanComponent } from './loan/loan.component';
import { DepositComponent } from './deposit/deposit.component';
import { ContactusComponent } from './contactus/contactus.component';
import { PersonalComponent } from './loan/personal/personal.component';
import { EducationComponent } from './loan/education/education.component';
import { VehicleComponent } from './loan/vehicle/vehicle.component';
import { HomeloanComponent } from './loan/homeloan/homeloan.component';

@NgModule({
  declarations: [
    AppComponent,
    HomeComponent,
    LoanComponent,
    DepositComponent,
    ContactusComponent,
    PersonalComponent,
    EducationComponent,
    VehicleComponent,
    HomeloanComponent
  ],
  imports: [
    BrowserModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
