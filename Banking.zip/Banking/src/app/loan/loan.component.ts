import { Component, OnInit } from '@angular/core';
import { getLocaleMonthNames } from '@angular/common';

@Component({
  selector: 'app-loan',
  templateUrl: './loan.component.html',
  styleUrls: ['./loan.component.css']
})
export class LoanComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }
  hvalue:boolean=false;
  lvalue:boolean=false;
  dvalue:boolean=false;
  cvalue:boolean=false;
  value:number;

  show(value)
  {
  if(value==1) 
  {
    this.hvalue=!false;
    this.lvalue=false;
    this.dvalue=false;
    this.cvalue=false;
  
  }       
  if(value==2) 
  {
    this.hvalue=false;
    this.lvalue=!false;
    this.dvalue=false;
    this.cvalue=false;
  
  }
  if(value==3) 
  {
    this.hvalue=false;
    this.lvalue=false;
    this.dvalue=!false;
    this.cvalue=false;
  
  }  
  if(value==4) 
  {
    this.hvalue=false;
    this.lvalue=false;
    this.dvalue=false;
    this.cvalue=!false;
  
  }  
}                 

}
