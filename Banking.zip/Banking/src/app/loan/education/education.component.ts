import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-education',
  templateUrl: './education.component.html',
  styleUrls: ['./education.component.css']
})
export class EducationComponent implements OnInit {
result:number;
interest:number;

  constructor() { }

  ngOnInit() {
  }

caluculate(amount:any,tenure:any,roi:any)
{
 tenure=parseInt(tenure)/12;
roi=parseInt(roi)/100;
this.result=eval(amount)*(1+(roi*eval(tenure)))
console.log(this.result);
}
}
