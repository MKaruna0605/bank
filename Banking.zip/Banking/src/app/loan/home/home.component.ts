import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-homea',
  templateUrl: './homea.component.html',
  styleUrls: ['./homea.component.css']
})
export class HomeComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
