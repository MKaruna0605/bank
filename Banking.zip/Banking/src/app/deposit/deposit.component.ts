import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-deposit',
  templateUrl: './deposit.component.html',
  styleUrls: ['./deposit.component.css']
})
export class DepositComponent implements OnInit {
p:number;
n:number;
m:number;
calculator1:number;
a:number;
b:number;
c:number;


A:number;
P:number;
R:number;
N:number;
t:number;

f:number;
g:number;
h:number;

J:number;
K:number;
L:number;
H:number;

n1:number=4;
br:number;

Q:number;

  constructor() { }

  ngOnInit() {
  }

  caluculator1(p, n, r)
  {
    this.a = (1+(eval(r)/400));
    this.b = 4*(eval(n)/12);
    this.c = Math.pow(this.a,this.b);
    this.calculator1 = p * this.c
  }

  rdcalc(P,R,t)
  {
    this.f=(1+eval(R)/400);
    this.g=4*(eval(t)/12);
    this.h=Math.pow(this.f,this.g);
    this.A=eval(P)*this.h;
    console.log(this.A);
  }
  rdcalc2(p,t)
  {
    p=eval(p);
    t=eval(t);
    this.f=1+.0825/this.n1;
    for(var i=12;i>=1;i--)
    {
      this.c=this.a;
      this.g=Math.pow(this.f,this.n1*(i/t));
      this.a=p*this.g;
      this.br=this.c+this.a;
    }
  }

  
  valuea(MI,y,i)
  {
    this.Q=eval(MI)*eval(y)*(1+((eval(y)+1)*(parseInt(i)/2400)))
   }

   valuea1(J,F,G)
   {
     this.K=Math.pow((1+(F/400)),(G-1))
     this.L=Math.pow((1+(F/400)),(-1/3))
this.H=J*(this.K/(1-this.L))
   }

}