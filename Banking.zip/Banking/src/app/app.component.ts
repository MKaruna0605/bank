import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'Banking';
  hvalue:boolean=false;
  lvalue:boolean=false;
  dvalue:boolean=false;
  cvalue:boolean=false;
  value:number;

  show(value)
  {
  if(value==1) 
  {
    this.hvalue=!false;
    this.lvalue=false;
    this.dvalue=false;
    this.cvalue=false;
  
  }       
  if(value==2) 
  {
    this.hvalue=false;
    this.lvalue=!false;
    this.dvalue=false;
    this.cvalue=false;
  
  }
  if(value==3) 
  {
    this.hvalue=false;
    this.lvalue=false;
    this.dvalue=!false;
    this.cvalue=false;
  
  }  
  if(value==4) 
  {
    this.hvalue=false;
    this.lvalue=false;
    this.dvalue=false;
    this.cvalue=!false;
  
  }                   
  }

}
